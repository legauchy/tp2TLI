package grapher.fc;

public interface Function {
	String toString();
	double y(double x);
}
